// Moved to interface, so that we could implement other policies.
public interface Pot {
    public void fill(int m);
    public void getServing();
}
