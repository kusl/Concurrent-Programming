public interface Pot {
    public void fill(int m);
    public void getServing();
}
